
function validarFormulario() {
  var tituloInput = document.getElementById('nome');
  var autorInput = document.getElementById('autor');
  var generoInput = document.getElementById('validationServer04');
  var editoraInput = document.getElementById('validationDefault04');
  var anoInput = document.getElementById('ano');
  var idiomaInput = document.getElementById('validationDefault06');
  var palavraChaveInput = document.getElementById('validationDefault07');
  var paginasInput = document.getElementById('validationDefault08');
  var descricaoInput = document.getElementById('tema');

  
  var valido = true;

  
  if (tituloInput.value.length < 10 || tituloInput.value.length > 30) {
    tituloInput.classList.add('is-invalid');
    tituloInput.nextElementSibling.textContent = 'O título deve ter entre 10 e 30 caracteres.';
    valido = false;
  } else {
    tituloInput.classList.remove('is-invalid');
    tituloInput.nextElementSibling.textContent = '';
  }

 
  if (autorInput.value.length < 10 || autorInput.value.length > 50) {
    autorInput.classList.add('is-invalid');
    autorInput.nextElementSibling.textContent = 'O nome do autor(a) deve ter entre 10 e 50 caracteres.';
    valido = false;
  } else {
    autorInput.classList.remove('is-invalid');
    autorInput.nextElementSibling.textContent = '';
  }

 
  if (generoInput.value === '') {
    generoInput.classList.add('is-invalid');
    generoInput.nextElementSibling.textContent = 'Escolha um gênero literário.';
    valido = false;
  } else {
    generoInput.classList.remove('is-invalid');
    generoInput.nextElementSibling.textContent = '';
  }

  
  if (editoraInput.value.length < 5 || editoraInput.value.length > 50) {
    editoraInput.classList.add('is-invalid');
    editoraInput.nextElementSibling.textContent = 'O nome da editora deve ter entre 5 e 50 caracteres.';
    valido = false;
  } else {
    editoraInput.classList.remove('is-invalid');
    editoraInput.nextElementSibling.textContent = '';
  }

  
  if (anoInput.value === '') {
    anoInput.classList.add('is-invalid');
    anoInput.nextElementSibling.textContent = 'Selecione uma data de publicação.';
    valido = false;
  } else {
    anoInput.classList.remove('is-invalid');
    anoInput.nextElementSibling.textContent = '';
  }

  a
  if (idiomaInput.value.length < 5 || idiomaInput.value.length > 30) {
    idiomaInput.classList.add('is-invalid');
    idiomaInput.nextElementSibling.textContent = 'O idioma deve ter entre 5 e 30 caracteres.';
    valido = false;
  } else {
    idiomaInput.classList.remove('is-invalid');
    idiomaInput.nextElementSibling.textContent = '';
  }

 
  if (palavraChaveInput.value.length < 5 || palavraChaveInput.value.length > 10) {
    palavraChaveInput.classList.add('is-invalid');
    palavraChaveInput.nextElementSibling.textContent = 'A palavra chave deve ter entre 5 e 10 caracteres.';
    valido = false;
  } else {
    palavraChaveInput.classList.remove('is-invalid');
    palavraChaveInput.nextElementSibling.textContent = '';
  }

  
  if (paginasInput.value < 1 || paginasInput.value > 99999) {
    paginasInput.classList.add('is-invalid');
    paginasInput.nextElementSibling.textContent = 'Informe um número válido de páginas.';
    valido = false;
  } else {
    paginasInput.classList.remove('is-invalid');
    paginasInput.nextElementSibling.textContent = '';
  }

  if (descricaoInput.value.length > 40) {
    descricaoInput.classList.add('is-invalid');
    descricaoInput.nextElementSibling.textContent = 'A descrição deve ter no máximo 40 caracteres.';
    valido = false;
  } else {
    descricaoInput.classList.remove('is-invalid');
    descricaoInput.nextElementSibling.textContent = '';
  }
  return valido;
}

document.getElementById('nome').addEventListener('input', validarFormulario);
document.getElementById('autor').addEventListener('input', validarFormulario);
document.getElementById('validationServer04').addEventListener('input', validarFormulario);
document.getElementById('validationDefault04').addEventListener('input', validarFormulario);
document.getElementById('ano').addEventListener('input', validarFormulario);
document.getElementById('validationDefault06').addEventListener('input', validarFormulario);
document.getElementById('validationDefault07').addEventListener('input', validarFormulario);
document.getElementById('validationDefault08').addEventListener('input', validarFormulario);
document.getElementById('tema').addEventListener('input', validarFormulario);

function validarCampos() {
  var tituloInput = document.querySelector('#nome');
  var autorInput = document.querySelector('#autor');
  var generoInput = document.querySelector('#validationServer04');
  var editoraInput = document.querySelector('#validationDefault04');
  var anoInput = document.querySelector('#ano');
  var idiomaInput = document.querySelector('#validationDefault06');
  var palavraChaveInput = document.querySelector('#validationDefault07');
  var paginasInput = document.querySelector('#validationDefault08');
  var descricaoInput = document.querySelector('#tema');

  var valido = true;

 
  if (tituloInput.value.length < 10 || tituloInput.value.length > 30) {
    tituloInput.classList.add('is-invalid');
    tituloInput.classList.remove('is-valid');
    valido = false;
  } else {
    tituloInput.classList.remove('is-invalid');
    tituloInput.classList.add('is-valid');
  }

  
  if (autorInput.value.length < 10 || autorInput.value.length > 50) {
    autorInput.classList.add('is-invalid');
    autorInput.classList.remove('is-valid');
    valido = false;
  } else {
    autorInput.classList.remove('is-invalid');
    autorInput.classList.add('is-valid');
  }

  
  if (generoInput.value === '') {
    generoInput.classList.add('is-invalid');
    generoInput.classList.remove('is-valid');
    valido = false;
  } else {
    generoInput.classList.remove('is-invalid');
    generoInput.classList.add('is-valid');
  }

  
  if (editoraInput.value.length < 5 || editoraInput.value.length > 50) {
    editoraInput.classList.add('is-invalid');
    editoraInput.classList.remove('is-valid');
    valido = false;
  } else {
    editoraInput.classList.remove('is-invalid');
    editoraInput.classList.add('is-valid');
  }

  
  if (anoInput.value === '') {
    anoInput.classList.add('is-invalid');
    anoInput.classList.remove('is-valid');
    valido = false;
  } else {
    anoInput.classList.remove('is-invalid');
    anoInput.classList.add('is-valid');
  }

  
  if (idiomaInput.value.length < 5 || idiomaInput.value.length > 30) {
    idiomaInput.classList.add('is-invalid');
    idiomaInput.classList.remove('is-valid');
    valido = false;
  } else {
    idiomaInput.classList.remove('is-invalid');
    idiomaInput.classList.add('is-valid');
  }

  
  if (palavraChaveInput.value.length < 5 || palavraChaveInput.value.length > 10) {
    palavraChaveInput.classList.add('is-invalid');
    palavraChaveInput.classList.remove('is-valid');
    valido = false;
  } else {
    palavraChaveInput.classList.remove('is-invalid');
    palavraChaveInput.classList.add('is-valid');
  }

 
  if (paginasInput.value < 1 || paginasInput.value > 99999) {
    paginasInput.classList.add('is-invalid');
    paginasInput.classList.remove('is-valid');
    valido = false;
  } else {
    paginasInput.classList.remove('is-invalid');
    paginasInput.classList.add('is-valid');
  }

  
  if (descricaoInput.value.length > 60) {
    descricaoInput.classList.add('is-invalid');
    descricaoInput.classList.remove('is-valid');
    valido = false;
  } else {
    descricaoInput.classList.remove('is-invalid');
    descricaoInput.classList.add('is-valid');
  }

  return valido;
}


function enviarFormulario(event) {
  event.preventDefault(); 

  if (validarCampos()) {
   
    console.log('Formulário enviado!');
  } else {
    console.log('Existem campos inválidos no formulário.');
  }
}


var inputs = document.querySelectorAll('input');
inputs.forEach(function(input) {
  input.addEventListener('input', validarCampos);
});



window.onload = function() {
    var botao = document.getElementById('botaoBuscar');
    botao.addEventListener('click', validarFormulario);
 
};
