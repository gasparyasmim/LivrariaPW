function validarFormulario() {
    var emailInput = document.getElementById("validationDefault01");
    var senhaInput = document.getElementById("validationDefault02");
  
    var email = emailInput.value.trim();
    if (email === "" || !validarFormatoEmail(email)) {
      exibirMensagemErro(emailInput, "Digite um e-mail válido.");
      return false;
    }
  
    if (senhaInput.value.trim() === "") {
      exibirMensagemErro(senhaInput, "Digite a senha.");
      return false;
    }
  
    return true;
  }
  
  function exibirMensagemErro(elemento, mensagem) {
    
    var mensagemErroAnterior = elemento.nextElementSibling;
    if (mensagemErroAnterior && mensagemErroAnterior.classList.contains("mensagem-erro")) {
      mensagemErroAnterior.remove();
    }
  
    var mensagemErro = document.createElement("span");
    mensagemErro.classList.add("mensagem-erro");
    mensagemErro.textContent = mensagem;
  
    elemento.parentNode.insertBefore(mensagemErro, elemento.nextSibling);
  }
  
  function validarFormatoEmail(email) {
    var formatoEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
    return formatoEmail.test(email);
  }
  
  document.addEventListener("DOMContentLoaded", function() {
    var form = document.querySelector("form");
    form.addEventListener("submit", function(event) {
      event.preventDefault();
      if (validarFormulario()) {
        alert("Login bem-sucedido!");
      }
    });
  });
  