function abrirMenu(){
    const divMenu = document.getElementById('respMenu').classList;
    divMenu.toggle('abrir');
    const ic = document.getElementById('icone');
    if(divMenu.contains('abrir'))
    {
      ic.innerHTML = 'close';
    }
    else
    {
      ic.innerHTML = 'menu';
    }  
}

// const inputs = document.querySelectorAll("[required]");
// inputs.forEach( (elemento) => {
//   elemento.addEventListener("blur" ,(evento)=>{
//     validaCampo(evento.target)
//   });

// });

// function validaCampo(campo){
//   const msnErro = campo.parentNode.querySelectorAll("[data-erro]");
//   if(campo.name ==="Nome"){
//     console.log(campo.value.length<5){
//       msnErro.textContent = "Digite o nome completo";

//     }
//     else{
//       msnErro.textContent = "";
//     }
  
//   }
// }