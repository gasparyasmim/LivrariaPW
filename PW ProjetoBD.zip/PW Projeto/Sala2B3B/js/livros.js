function validarFormulario() {
    var livroNomeInput = document.getElementById("livroNomeInput");
    var autorInput = document.getElementById("autorInput");
    var generosInput = document.getElementById("generosInput");
    var editoraInput = document.getElementById("editoraInput");
    var dataPublicacaoInput = document.getElementById("dataPublicacaoInput");
    var idiomaInput = document.getElementById("idiomaInput");
    var precoInput = document.getElementById("precoInput");
    var paginasInput = document.getElementById("paginasInput");
    var idadeLeituraInput = document.getElementById("idadeLeituraInput");
  
    if (livroNomeInput.value.trim() === "") {
      exibirMensagemErro(livroNomeInput, "Digite o nome do livro.");
      return false;
    }
  
    if (autorInput.value.trim() === "") {
      exibirMensagemErro(autorInput, "Digite o nome do autor(a).");
      return false;
    }
  
    if (generosInput.value.trim() === "") {
      exibirMensagemErro(generosInput, "Digite os gêneros do livro.");
      return false;
    }
  
    if (editoraInput.value.trim() === "") {
      exibirMensagemErro(editoraInput, "Digite o nome da editora.");
      return false;
    }
  
    var dataPublicacao = dataPublicacaoInput.value.trim();
    if (dataPublicacao === "" || !validarFormatoData(dataPublicacao)) {
      exibirMensagemErro(dataPublicacaoInput, "Digite uma data de publicação válida (DD/MM/AAAA).");
      return false;
    }
  
    if (idiomaInput.value.trim() === "") {
      exibirMensagemErro(idiomaInput, "Digite o idioma original do livro.");
      return false;
    }
  
    var preco = precoInput.value.trim();
    if (preco === "" || !validarFormatoPreco(preco)) {
      exibirMensagemErro(precoInput, "Digite um preço válido (exemplo: 9.99).");
      return false;
    }
  
    var paginas = paginasInput.value.trim();
    if (paginas === "" || !validarFormatoPaginas(paginas)) {
      exibirMensagemErro(paginasInput, "Digite um número válido de páginas.");
      return false;
    }
  
    var idadeLeitura = idadeLeituraInput.value.trim();
    if (idadeLeitura === "" || !validarFormatoIdadeLeitura(idadeLeitura)) {
      exibirMensagemErro(idadeLeituraInput, "Digite uma idade de leitura válida (exemplo: 12+).");
      return false;
    }
  
    return true;
  }
  
  function exibirMensagemErro(elemento, mensagem) {
    var mensagemErroAnterior = elemento.nextElementSibling;
    if (mensagemErroAnterior && mensagemErroAnterior.classList.contains("mensagem-erro")) {
      mensagemErroAnterior.remove();
    }
  
    var mensagemErro = document.createElement("span");
    mensagemErro.classList.add("mensagem-erro");
    mensagemErro.textContent = mensagem;
  
    elemento.parentNode.insertBefore(mensagemErro, elemento.nextSibling);
  }
  
  function validarFormatoData(data) {
    var formatoData = /^\d{2}\/\d{2}\/\d{4}$/;
  
    return formatoData.test(data);
  }
  
  function validarFormatoPreco(preco) {
    var formatoPreco = /^\d+(\.\d{1,2})?$/;
  
    return formatoPreco.test(preco);
  }
  
  function validarFormatoPaginas(paginas) {
    var formatoPaginas = /^\d+$/;
  
    return formatoPaginas.test(paginas);
  }
  
  function validarFormatoIdadeLeitura(idadeLeitura) {
    var formatoIdadeLeitura = /^\d+(\+)?$/;

    return formatoIdadeLeitura.test(idadeLeitura);
  }
  