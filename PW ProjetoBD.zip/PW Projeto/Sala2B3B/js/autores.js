function validarFormulario() {    
  var nome = document.getElementById('nome').value;
  var email = document.getElementById('email').value;
  var cpf = dcument.getElementById('cpf');
 
 
  if (nome.trim() === '') {
      exibirMensagem('O campo "Nome" é obrigatório.', false);
      return false;
    }
  
    var emailRegex = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
    if (!emailRegex.test(email)) {
      exibirMensagem('O campo "E-mail" deve ser um endereço de e-mail válido.', false);
      return false;
    }
  
    
    if (!validarCPF(cpf)) {
      exibirMensagem('O campo "CPF" deve conter um CPF válido.', false);
      return false;
    }
  
    if (!validarISBN(isbn)) {
      exibirMensagem('O campo "ISBN" deve conter um ISBN válido.', false);
      return false;
    }
  
    exibirMensagem('Formulário válido!', true);
    document.getElementById('buscarForm').submit(); 
  
    return true;
  }
  
  function exibirMensagem(mensagem, sucesso = true) {
    var mensagemElement = document.getElementById('mensagem');
    mensagemElement.textContent = mensagem;
  
    if (sucesso) {
      mensagemElement.classList.add('sucesso');
      mensagemElement.classList.remove('erro');
    } else {
      mensagemElement.classList.add('erro');
      mensagemElement.classList.remove('sucesso');
    }
  }
  
function validarCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');

  if (cpf.length !== 11) {
    return false;
  }

  if (/^(\d)\1+$/.test(cpf)) {
    return false;
  }

  var soma = 0;
  var resto;

  for (var i = 1; i <= 9; i++) {
    soma += parseInt(cpf.charAt(i - 1)) * (11 - i);
  }

  resto = (soma * 10) % 11;

  if (resto === 10 || resto === 11) {
    resto = 0;
  }

  if (resto !== parseInt(cpf.charAt(9), 10)) {
    return false;
  }

  soma = 0;

  for (i = 1; i <= 10; i++) {
    soma += parseInt(cpf.charAt(i - 1)) * (12 - i);
  }

  resto = (soma * 10) % 11;

  if (resto === 10 || resto === 11) {
    resto = 0;
  }

  if (resto !== parseInt(cpf.charAt(10), 10)) {
    return false;
  }

  return true;
}

 
function formatarTelefone() {
  var telefone = document.getElementById('telefone').value;

 
  telefone = telefone.replace(/\D/g, '');

 
  telefone = telefone.replace(/^(\d{2})(\d)/g, '($1) $2');
  telefone = telefone.replace(/(\d)(\d{4})$/, '$1-$2');

 
  document.getElementById('telefone').value = telefone;
} 

function formatarISBN() {
  var isbn = document.getElementById('isbn').value;

  
  isbn = isbn.replace(/[^0-9X]/gi, '');

  
  var grupos = [3, 1, 2, 6, 1];

  var mascara = '';
  var indice = 0;

  // Aplicar máscara
  for (var i = 0; i < grupos.length; i++) {
    var grupo = isbn.substr(indice, grupos[i]);
    if (grupo) {
      mascara += grupo;
      if (i < grupos.length - 1) {
        mascara += '-';
      }
      indice += grupos[i];
    }
  }

  document.getElementById('isbn').value = mascara;
}


var inputs = document.querySelectorAll('input');

inputs.forEach(function(input) {
  input.addEventListener('blur', function() {
    validaCampo(this);
  });
});

function validaCampo(campo) {
  const msnErro = campo.parentNode.querySelector("[data-erro]");

  if (campo.name === "Nome") {
    if (campo.value.length < 5) {
      msnErro.textContent = "Digite o nome completo";
    } else {
      msnErro.textContent = "";
    }
  }
}

  window.onload = function() {
      var botao = document.getElementById('botaoBuscar');
      botao.addEventListener('click', validarFormulario);
   
  };

      