function validarFormulario(event) {
    event.preventDefault(); 
    var email = document.getElementById('emailInput').value;
    var senha = document.getElementById('senhaInput').value;
    var nome = document.getElementById('nomeInput').value;
    var cpf = document.getElementById('cpfInput').value;
    var genero = document.getElementById('generoInput').value;
    var dataNascimento = document.getElementById('dataNascimentoInput').value;
    var estado = document.getElementById('estadoInput').value;
    var estadoCivil = document.getElementById('estadoCivilInput').value;
  
    if (!validarEmail(email)) {
      exibirMensagem('E-mail inválido');
      return;
    }
  
    if (!validarSenha(senha)) {
      exibirMensagem('Senha inválida. A senha deve ter pelo menos 6 caracteres');
      return;
    }
  
    if (!validarNome(nome)) {
      exibirMensagem('Nome inválido. O nome deve conter apenas letras');
      return;
    }
  
    if (!validarCPF(cpf)) {
      exibirMensagem('CPF inválido. O CPF deve conter 11 dígitos numéricos');
      return;
    }
  
    if (!validarGenero(genero)) {
      exibirMensagem('Gênero inválido. Selecione uma opção válida');
      return;
    }
  
    if (!validarDataNascimento(dataNascimento)) {
      exibirMensagem('Data de Nascimento inválida');
      return;
    }
  
    if (!validarEstado(estado)) {
      exibirMensagem('Estado inválido. Digite um estado válido');
      return;
    }
  
    if (!validarEstadoCivil(estadoCivil)) {
      exibirMensagem('Estado Civil inválido. Selecione uma opção válida');
      return;
    }
  
    exibirMensagem('Formulário enviado com sucesso!');
  }
  
  function validarEmail(email) {
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }
  
  function validarSenha(senha) {
    return senha.length >= 6;
  }
  
  function validarNome(nome) {
    var nomePattern = /^[A-Za-zÀ-ÖØ-öø-ÿ ]+$/;
    return nomePattern.test(nome);
  }
  
function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
  
    if (cpf.length !== 11) {
      return false;
    }
  
    if (/^(\d)\1+$/.test(cpf)) {
      return false;
    }
  
    var soma = 0;
    for (var i = 0; i < 9; i++) {
      soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    var resto = 11 - (soma % 11);
    var digitoVerificador1 = resto > 9 ? 0 : resto;
  
    if (digitoVerificador1 !== parseInt(cpf.charAt(9))) {
      return false;
    }
  
    soma = 0;
    for (var j = 0; j < 10; j++) {
      soma += parseInt(cpf.charAt(j)) * (11 - j);
    }
    resto = 11 - (soma % 11);
    var digitoVerificador2 = resto > 9 ? 0 : resto;
  
    if (digitoVerificador2 !== parseInt(cpf.charAt(10))) {
      return false;
    }
  
    return true;
  }
  
  
  function validarGenero(genero) {
    return genero !== '';
  }
  
  function validarDataNascimento(dataNascimento) {
    var dataPattern = /^\d{2}\/\d{2}\/\d{4}$/;
    return dataPattern.test(dataNascimento);
  }
  
  function validarEstado(estado) {
    return estado.trim() !== '';
  }
  function validarEstadoCivil(estadoCivil) {
    return estadoCivil !== '';
  }
  function exibirMensagem(mensagem) {
    var mensagemElement = document.getElementById('mensagem');
    mensagemElement.textContent = mensagem;
    mensagemElement.style.display = 'block';
  }
  var formulario = document.getElementById('formulario');
  formulario.addEventListener('submit', validarFormulario);
  