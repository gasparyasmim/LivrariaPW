function formatarCPF() {
    const cpfInput = document.getElementById('cpf');
    let cpf = cpfInput.value;
  
    // Remove todos os caracteres que não são dígitos
    cpf = cpf.replace(/\D/g, '');
  
    // Adiciona a máscara no CPF
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  
    // Atualiza o valor do input
    cpfInput.value = cpf;
  
  }