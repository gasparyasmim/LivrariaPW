<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
    
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$link = $_POST["link"];
$cidade = $_POST["cidade"];
$cpf = $_POST["cpf"];
$editora = $_POST["editora"];
$contato = $_POST["contato"];


$sql = "INSERT INTO autores ( nome_aut, sobrenome_aut, email_aut, senha_aut, link_social_aut, cidade_aut, cpf_aut, editora_aut, contato_aut ) values ( '$nome', '$sobrenome', '$email', '$senha', '$link', '$cidade', '$cpf', '$editora', '$contato')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>