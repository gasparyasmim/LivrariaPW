<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
    
$nome = $_POST["nome"];
$fundador = $_POST["fundador"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$link = $_POST["link"];
$sede = $_POST["sede"];
$isnb = $_POST["isnb"];
$genero = $_POST["genero"];
$contato = $_POST["contato"];


$sql = "INSERT INTO editora ( nome_edi, fundador_edi, email_edi, senha_edi, link_social_edi, sede_edi, isnb_edi, genero_literario_edi, contato_edi ) values ( '$nome', '$fundador', '$email', '$senha', '$link', '$sede', '$isnb', '$genero', '$contato')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>