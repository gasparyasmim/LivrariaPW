<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
$nome = $_POST["nome"];    
$autor = $_POST["autor"];
$senha = $_POST["senha"];
$generos = $_POST["generos"];
$editora = $_POST["editora"];
$data_publicacao = $_POST["data_publicacao"];
$idioma = $_POST["idioma"];
$preco = $_POST["preco"];
$paginas = $_POST["paginas"];
$idade = $_POST["idade"];


$sql = "INSERT INTO livros ( nome_liv, autor_liv, senha_liv, generos_liv, editora_liv, data_publicacao_liv, idioma_original_liv, preco_liv, paginas_liv, idade_leitura_liv ) values ( '$nome', '$autor', '$senha', '$generos', '$editora', '$data_publicacao', '$idioma', '$preco', '$paginas', '$idioma', '$idade')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>