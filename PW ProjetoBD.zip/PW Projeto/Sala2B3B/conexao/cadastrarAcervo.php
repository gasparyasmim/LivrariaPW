<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
    
$titulo = $_POST["titulo"];
$autor = $_POST["autor"];
$genero = $_POST["genero"];
$editora = $_POST["editora"];
$palavraChave = $_POST["palavraChave"];
$idioma = $_POST["idioma"];
$descricao = $_POST["descricao"];
$publicacao = $_POST["publicacao"];
$paginas = $_POST["paginas"];



$sql = "INSERT INTO acervo ( titulo_ace, autor_ace, genero_ace, editora_ace, palavra_chave_ace, idioma_ace,  descricao_ace, data_publicacao_ace, paginas_ace ) values ( '$titulo', '$autor', '$genero', '$editora', '$palavraChave', '$idioma', '$descricao', '$publicacao', '$paginas')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>