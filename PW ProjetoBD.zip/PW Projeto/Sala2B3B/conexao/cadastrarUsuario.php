<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
    
$email = $_POST["email"];
$senha = $_POST["senha"];
$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$genero = $_POST["genero"];
$data_nascimento = $_POST["data_nascimento"];
$estado = $_POST["estado"];
$estado_civil = $_POST["estado_civil"];


$sql = "INSERT INTO funcionario ( email_usu, senha_usu, nome_completo_usu, cpf_usu, genero_usu, estado_usu, data_nascimento_usu, estado_civil_usu ) values ( '$email', '$senha', '$nome', '$cpf', '$genero', '$estado', '$data_nascimento', '$estado_civil')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>