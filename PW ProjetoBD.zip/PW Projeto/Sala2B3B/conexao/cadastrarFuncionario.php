<?php
$_con = mysqli_connect('127.0.0.1','root','','Livraria_PW');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

   
    
$email = $_POST["email"];
$senha = $_POST["senha"];
$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$genero = $_POST["genero"];
$nascimento = $_POST["nascimento"];
$estado = $_POST["estado"];


$sql = "INSERT INTO funcionario ( email_fun, senha_fun, nome_fun, cpf_fun, genero_fun, data_nascimento_fun, estado_fun ) values ( '$email', '$senha', '$nome', '$cpf', '$genero', '$nascimento', '$estado')";



    if ($_con->query($sql) === TRUE) {
        echo"Dados inseridos com sucesso!";
    } else {
        echo"Erro na inserção: " . $_con->error;
    }

    $_con->close();
}
else{
    echo "Erro de Dados";
}
?>