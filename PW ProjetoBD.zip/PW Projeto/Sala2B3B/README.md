# Sala2B3B
# 3° B - Informática
#Livraria
Trabalho com Formulários 2° Bimestre, PROGRAMAÇÃO WEB.
Integrantes: Mailon Camargo e Yasmim Gaspar.
Yasmim Formulários: Cadastro Autor, Cadastro Acervo, Cadastro Editora e index. 
Mailon Formulários: Cadastro Livro, Cadastro Usuário, Cadastro Funcionário e Login.
